package eduonix.spark;

/**
 * Created by ubu on 1/25/2015.
 */
public class Tester {

    public static void main(String[] args) {
        System.out.println("testing 1 2 3 ");
    }
}
